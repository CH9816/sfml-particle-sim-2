#pragma once
#include<SFML/Graphics.hpp>
#include<vector>
#include<string>
#include<thread>
