#pragma once
#include "defines.hpp"

extern float mouseScroll;
//extern vectorList<sf::Color> colourIdMap;