#pragma once


enum class IntegratorType {
	Euler,
	Verlet,
	RungeKutta4
};